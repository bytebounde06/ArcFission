ArcFission original code in this folder is licensed under MPL-2.0 (see /LICENSE).
Original art assets are licensed under CC BY-NC-SA 4.0.
Game files, data, and assets from [Mojang / RocketWerkz / Activision] remain
the property of their owners and are not covered by these licenses.
