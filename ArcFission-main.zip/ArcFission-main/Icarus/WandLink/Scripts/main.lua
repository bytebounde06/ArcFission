--[[
  WandLink - UE4SS Lua mod for Icarus
  Link two containers with a stick "wand", and items flow from one into
  the other automatically. No keybinds: everything is done in game with
  chat commands and by opening containers.

  HOW TO USE (any player, host or friend):
    1. Type  /wand  in chat to turn wand mode on.
    2. Hold a stick (one stick or a stack) in your hand.
    3. Open the FROM container with E (a cupboard, a drill, ...).
    4. Open the TO container with E. The link is made and saved.
    5. Type  /wand  again to turn wand mode off.

  OTHER COMMANDS
    /wand remove : the next container you open (holding a stick) has
                   its links removed
    /wand cancel : forget a FROM container you picked but didn't link yet
    /wand list   : how many links you own, and how many exist in total
    /wand help   : show these commands in chat

  Only the host needs this mod installed. Links are saved to links.txt in
  this mod's folder and reconnect after a restart.

  Needs a UE4SS experimental build (the stable v3.0.1 build can't move
  items).
]]

---------------------------------------------------------------------
-- CONFIG
---------------------------------------------------------------------
local CONFIG = {
    -- Unreal units are centimeters. 1000 = 10 meters.
    MAX_DISTANCE     = 900000.0, -- containers further apart can't be linked (9 km)
    MIN_DISTANCE     = 100.0,    -- containers closer than this can't be linked
    TICK_MS          = 2000,     -- how often items are moved
    ITEMS_PER_TICK   = 1,        -- stacks moved per link per tick

    -- The wand: the player must have an item whose name contains one of
    -- these words in their hand (not case sensitive).
    WAND_ITEM_MATCH  = { "stick" },

    -- If the mod can't work out what a player is holding at all, true lets
    -- the wand work anyway; false blocks it (and logs why).
    ALLOW_IF_HELD_ITEM_UNKNOWN = false,

    -- Which containers can be linked. Pieces of class names, not case
    -- sensitive. Leave a list empty ({}) to allow anything that has an
    -- inventory.
    SOURCE_CLASSES   = {},       -- FROM side
    DEST_CLASSES     = {},       -- TO side

    -- Who may remove a link with /wand remove:
    --   true  = only the player who made it, or the host
    --   false = anyone using the wand
    ONLY_OWNER_CAN_REMOVE = true,

    -- Send replies in the game chat. If chat replies cause any trouble,
    -- set this to false: replies then only go to UE4SS.log.
    -- Replies are sent as the host: the game needs a real player as the
    -- sender of a chat message, and shows that player's name and Steam
    -- avatar. CHAT_PREFIX goes in front of every reply so it's clear the
    -- message is from the mod. Use "" for no prefix.
    CHAT_REPLIES     = true,
    CHAT_PREFIX      = "[Wand] ",
    REPLY_AS_HOST    = true,
    CHAT_SENDER_NAME = "Wand",

    -- OPTIONAL KEYBINDS (off by default). See README.md before turning on.
    -- For the host, keys run the /wand command directly. For a friend who
    -- joins, keys send the /wand command through chat (it shows in chat)
    -- and the host's copy of WandLink runs it, so the host needs WandLink.
    KEYBINDS = {
        ENABLED       = true,
        -- /wand from, /wand to and /wand clear (what F5, F6, F8 send) also need
        -- a stick in hand. This one is read from the HOST's settings.
        REQUIRE_STICK = true,
        TOGGLE_WAND   = "F4",   -- same as /wand
        SET_FROM      = "F5",   -- nearest container becomes FROM
        SET_TO        = "F6",   -- nearest container becomes TO (makes the link)
        CANCEL        = "F7",   -- same as /wand cancel
        REMOVE        = "F8",   -- remove links on the nearest container (/wand clear)
        LIST          = "F9",   -- same as /wand list
    },

    -- Items whose ID contains any of these words are never moved
    -- (e.g. fuel stays in a drill).
    EXCLUDE_ITEM_MATCH = { "fuel" },

    MATCH_TOLERANCE  = 50.0,     -- how close (cm) a container must be to its saved position
    RECONNECT_EVERY_TICKS = 3,   -- how often to look for unloaded containers again
    PICK_RADIUS      = 600.0,    -- fallback search radius around the player

    LOG_MOVES        = false,    -- true: log every stack that is moved
    VERBOSE          = false,    -- true: also log detailed [debug] lines

    -- Write every risky step to trace.txt in this folder (for tracking
    -- down crashes). The last line after a crash shows what was running.
    TRACE            = false,
}

---------------------------------------------------------------------
-- BASIC HELPERS
---------------------------------------------------------------------
local links = {}          -- { ownerId, ownerName, srcId, dstId, src, dst, ... }
local players = {}        -- playerKey -> { on, mode, from, lastOpenKey, lastOpenAt }

local function log(msg)
    print("[WandLink] " .. tostring(msg) .. "\n")
end

local function valid(obj)
    if obj == nil then return false end
    local ok, res = pcall(function() return obj:IsValid() end)
    return ok and res == true
end

local function clip(v)
    local s = tostring(v)
    s = s:gsub("[^\32-\126\n\t]", "?")
    if #s > 400 then s = s:sub(1, 400) .. "..." end
    return s
end

local function unwrap(v)
    local out = v
    pcall(function()
        if (type(v) == "userdata" or type(v) == "table") and v.get then
            local inner = v:get()
            if inner ~= nil then out = inner end
        end
    end)
    return out
end

-- Turns an FString / FText / FName / Lua string into a Lua string, or nil.
local function toText(v)
    if v == nil then return nil end
    if type(v) == "string" then return v end
    if type(v) == "number" or type(v) == "boolean" then return nil end
    local ok, s = pcall(function() return v:ToString() end)
    if ok and type(s) == "string" then return s end
    return nil
end

local function lowerHasAny(s, list)
    if not s or not list then return false end
    local low = string.lower(s)
    for _, w in ipairs(list) do
        if w ~= "" and string.find(low, string.lower(w), 1, true) then return true end
    end
    return false
end

local function shortClass(actor)
    local full = "?"
    pcall(function() full = actor:GetClass():GetFullName() end)
    return full:match("[^%.]+$") or full
end

-- A friendlier name for chat: "BP_Metal_Cupboard_C" -> "Metal Cupboard"
local function prettyName(actor)
    local c = shortClass(actor)
    c = c:gsub("^BP_", ""):gsub("_C$", ""):gsub("_", " ")
    return c
end

local function locationOf(actor)
    local loc = actor:K2_GetActorLocation()
    return loc.X, loc.Y, loc.Z
end

local function distance(a, b)
    local ax, ay, az = locationOf(a)
    local bx, by, bz = locationOf(b)
    local dx, dy, dz = ax - bx, ay - by, az - bz
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

local function sameObject(a, b)
    if not (valid(a) and valid(b)) then return false end
    local ok, res = pcall(function() return a:GetFullName() == b:GetFullName() end)
    return ok and res
end

---------------------------------------------------------------------
-- TRACE + CRASH GUARD
-- trace.txt gets one line per step of anything risky, written straight to
-- disk, so after a crash its LAST line shows exactly what was running.
-- crash_guard.txt names the link being moved right now; if the game
-- crashes mid-transfer, that link is switched off on the next start.
---------------------------------------------------------------------
local MOD_DIR
do
    local ok, src = pcall(function() return debug.getinfo(1, "S").source end)
    if ok and type(src) == "string" then
        src = src:gsub("^@", "")
        MOD_DIR = src:match("^(.*)[/\\]Scripts[/\\][^/\\]+$")
    end
end

local traceLines = 0
local function trace(msg)
    if not CONFIG.TRACE or not MOD_DIR then return end
    local mode = "a"
    if traceLines == 0 or traceLines >= 3000 then mode = "w"; traceLines = 0 end
    local f = io.open(MOD_DIR .. "\\trace.txt", mode)
    if f then
        f:write(os.date("%H:%M:%S") .. string.format(".%03d ", math.floor((os.clock() % 1) * 1000)) .. tostring(msg) .. "\n")
        f:flush()
        f:close()
        traceLines = traceLines + 1
    end
end

local function setGuard(text)
    if not MOD_DIR then return end
    local f = io.open(MOD_DIR .. "\\crash_guard.txt", "w")
    if f then f:write(text); f:flush(); f:close() end
end

local function clearGuard()
    if MOD_DIR then os.remove(MOD_DIR .. "\\crash_guard.txt") end
end

local function readGuard()
    if not MOD_DIR then return nil end
    local f = io.open(MOD_DIR .. "\\crash_guard.txt", "r")
    if not f then return nil end
    local s = f:read("a")
    f:close()
    return s
end

local debugBudget, seenDebug = 80, {}
local function dbg(msg)
    if not CONFIG.VERBOSE then return end
    if debugBudget > 0 and not seenDebug[msg] then
        seenDebug[msg] = true
        debugBudget = debugBudget - 1
        log("[debug] " .. msg)
    end
end

local seenWarn = {}
local function warnOnce(msg)
    if not seenWarn[msg] then
        seenWarn[msg] = true
        log("WARNING: " .. msg)
    end
end

---------------------------------------------------------------------
-- PLAYERS
---------------------------------------------------------------------
local function isPlayerCharacter(obj)
    return valid(obj) and string.find(shortClass(obj), "PlayerCharacter", 1, true) ~= nil
end

local function isPlayerController(obj)
    return valid(obj) and string.find(shortClass(obj), "PlayerController", 1, true) ~= nil
end

local function controllerOf(pawn)
    local pc
    pcall(function() pc = pawn.Controller end)
    if valid(pc) then return pc end
    pcall(function() pc = pawn:GetController() end)
    if valid(pc) then return pc end
    return nil
end

local function pawnOf(pc)
    local pawn
    pcall(function() pawn = pc.Pawn end)
    if valid(pawn) then return pawn end
    return nil
end

local function playerStateOf(obj)
    local ps
    pcall(function() ps = obj.PlayerState end)
    if valid(ps) then return ps end
    return nil
end

-- A stable key for a player (their user/Steam ID when readable) plus a
-- display name.
local function playerIdentity(pc, pawn)
    local ps = (pc and playerStateOf(pc)) or (pawn and playerStateOf(pawn))
    local id, name
    if ps then
        pcall(function() id = toText(unwrap(ps:GetUserID())) end)
        pcall(function() name = toText(unwrap(ps:GetPlayerName())) end)
        if not name then pcall(function() name = toText(ps.PlayerNamePrivate) end) end
    end
    name = (name and name ~= "") and name or "Player"
    if not id or id == "" then id = "name:" .. name end
    name = name:gsub("[;\r\n]", " ")
    id = id:gsub("[;\r\n]", " ")
    return id, name
end

local function isHost(pc)
    if not valid(pc) then return false end
    local ok, res = pcall(function() return pc:IsLocalController() end)
    return ok and res == true
end

-- True when this copy of the game is the host (or single player). A
-- friend's copy of the mod, joined to someone else's world, must stay
-- idle (apart from forwarding keybinds), or it would answer /wand itself.
--
-- The test: does this computer have authority over its OWN player
-- controller? On the host it does (Role 3 = Authority); on a joined
-- client it doesn't (Role 2 = AutonomousProxy). This is checked fresh
-- each time, so leaving a world and hosting another works.
local lastRoleNotice = nil
local function localController()
    local all
    pcall(function() all = FindAllOf("PlayerController") end)
    for _, pc in ipairs(all or {}) do
        local okName, n = pcall(function() return pc:GetFullName() end)
        if valid(pc) and not (okName and n and n:find("Default__", 1, true)) then
            local ok, isLocal = pcall(function() return pc:IsLocalController() end)
            if ok and isLocal == true then return pc end
        end
    end
    return nil
end

local function isServer()
    local pc = localController()
    if not pc then return false end   -- no world loaded yet

    local server = nil
    local okA, auth = pcall(function() return pc:HasAuthority() end)
    if okA and type(auth) == "boolean" then server = auth end
    if server == nil then
        local okR, role = pcall(function() return tonumber(unwrap(pc.Role)) end)
        if okR and role then server = (role == 3) end
    end
    if server == nil then
        -- Last resort: a real (non-template) GameMode only exists on the host.
        local gms
        pcall(function() gms = FindAllOf("GameModeBase") end)
        server = false
        for _, gm in ipairs(gms or {}) do
            local okN, n = pcall(function() return gm:GetFullName() end)
            if valid(gm) and okN and n and not n:find("Default__", 1, true) then server = true break end
        end
    end

    local notice = server and "host" or "client"
    if notice ~= lastRoleNotice then
        lastRoleNotice = notice
        if server then
            log("This game is the host (or single player): WandLink is active.")
        else
            log("You're joined to someone else's world, so WandLink stays idle here. " ..
                "The host's copy handles /wand for everyone (your keybinds are forwarded to it).")
        end
    end
    return server
end

local function stateFor(key)
    local s = players[key]
    if not s then
        s = { on = false, mode = "link", from = nil }
        players[key] = s
    end
    return s
end

---------------------------------------------------------------------
-- CHAT REPLIES
-- Messages go to one player's chat through the game's own
-- ClientReceiveChatMessage. Its parameters are read from the game at
-- startup (and logged), so the call matches whatever this game version
-- expects. If it fails once, chat replies switch off and everything is
-- still written to UE4SS.log.
---------------------------------------------------------------------
local function describeParams(path)
    local fn = StaticFindObject(path)
    if not valid(fn) then return nil end
    local params = {}
    pcall(function()
        fn:ForEachProperty(function(p)
            local entry = { name = "?", ptype = "?", fields = nil }
            pcall(function() entry.name = p:GetFName():ToString() end)
            pcall(function() entry.ptype = p:GetClass():GetFName():ToString() end)
            if entry.ptype == "ObjectProperty" then
                pcall(function()
                    local c = p:GetPropertyClass()
                    if valid(c) then
                        entry.objClass = c
                        entry.objClassName = c:GetFName():ToString()
                    end
                end)
            end
            if entry.ptype == "StructProperty" then
                entry.fields = {}
                pcall(function()
                    p:GetStruct():ForEachProperty(function(f)
                        local fe = { name = "?", ptype = "?" }
                        pcall(function() fe.name = f:GetFName():ToString() end)
                        pcall(function() fe.ptype = f:GetClass():GetFName():ToString() end)
                        if fe.ptype == "ObjectProperty" then
                            pcall(function()
                                local c = f:GetPropertyClass()
                                if valid(c) then
                                    fe.objClass = c
                                    fe.objClassName = c:GetFName():ToString()
                                end
                            end)
                        end
                        table.insert(entry.fields, fe)
                    end)
                end)
            end
            if entry.name ~= "ReturnValue" then table.insert(params, entry) end
        end)
    end)
    return params
end

local function paramsToString(params)
    if not params then return "(not found)" end
    local parts = {}
    for _, p in ipairs(params) do
        local s = p.name .. ":" .. p.ptype
        if p.objClassName then s = s .. "<" .. p.objClassName .. ">" end
        if p.fields then
            local fs = {}
            for _, f in ipairs(p.fields) do fs[#fs + 1] = f.name .. ":" .. f.ptype end
            s = s .. "{" .. table.concat(fs, ", ") .. "}"
        end
        parts[#parts + 1] = s
    end
    return "(" .. table.concat(parts, "; ") .. ")"
end

local CHAT_SEND_PATH = "/Script/Icarus.IcarusPlayerController:ServerSendChatMessage"
local CHAT_RECV_PATH = "/Script/Icarus.IcarusPlayerController:ClientReceiveChatMessage"
local sendParams, recvParams
local chatRepliesWork = CONFIG.CHAT_REPLIES

local function isSenderField(name)
    local low = string.lower(name)
    return string.find(low, "sender", 1, true) or string.find(low, "player", 1, true)
        or string.find(low, "author", 1, true) or string.find(low, "from", 1, true)
        or low == "name"
end

local function valueFor(ptype, fieldName, msg)
    local text = isSenderField(fieldName) and CONFIG.CHAT_SENDER_NAME or msg
    if ptype == "StrProperty" then return text end
    if ptype == "TextProperty" then
        local ok, t = pcall(function() return FText(text) end)
        if ok then return t end
        return nil
    end
    if ptype == "NameProperty" then
        local ok, n = pcall(function() return FName(text) end)
        if ok then return n end
        return nil
    end
    return nil
end

-- Builds a value of the given property type from a Lua string.
local textWarned = false
local function makeValue(ptype, s)
    if ptype == "StrProperty" then return s end
    if ptype == "TextProperty" then
        local ok, t = pcall(function() return FText(s) end)
        if ok and t ~= nil then return t end
        if not textWarned then
            textWarned = true
            log("[chat] this UE4SS build can't create FText values, so a text field is sent as a plain string.")
        end
        return s
    end
    if ptype == "NameProperty" then
        local ok, n = pcall(function() return FName(s) end)
        if ok and n ~= nil then return n end
        return s
    end
    return nil
end

local function isStringType(ptype)
    return ptype == "StrProperty" or ptype == "TextProperty" or ptype == "NameProperty"
end

-- A real chat message, captured the first time the game shows one, used as
-- the template for replies: every field keeps the value the game used, and
-- only the text (and sender name) are swapped.
local chatTemplate      -- [paramIndex] = { [fieldName] = { ptype=, value= } } (or .value for plain params)
local templateTextKey   -- { i = paramIndex, field = fieldName or nil }
local recentPlayerChat = {}  -- text -> os.time() it was sent

local function readValue(ptype, raw)
    raw = unwrap(raw)
    if isStringType(ptype) then return toText(raw) end
    if type(raw) == "number" or type(raw) == "boolean" then return raw end
    if ptype == "ObjectProperty" and valid(raw) then return "<" .. shortClass(raw) .. ">" end
    return nil
end

-- The object the game uses as a chat message's sender: the host's
-- PlayerState, PlayerController or character, whichever fits the type the
-- message expects. The game takes the sender's name and avatar from it.
local senderLogged = false
local function hostSenderObject(info, sampledClass)
    local hostPC
    local all
    pcall(function() all = FindAllOf("PlayerController") end)
    for _, pc in ipairs(all or {}) do
        if isHost(pc) then hostPC = pc break end
    end
    if not hostPC then return nil end
    local cands = { playerStateOf(hostPC), hostPC, pawnOf(hostPC) }
    local chosen
    for _, c in ipairs(cands) do
        if valid(c) then
            local fits = false
            if info and info.objClass then
                local ok, res = pcall(function() return c:IsA(info.objClass) end)
                fits = ok and res == true
            end
            if not fits and sampledClass and shortClass(c) == sampledClass then fits = true end
            if not fits and not (info and info.objClass) and not sampledClass then
                -- nothing to go on: a chat sender is normally a PlayerState
                fits = string.find(shortClass(c), "PlayerState", 1, true) ~= nil
            end
            if fits then chosen = c break end
        end
    end
    if not senderLogged then
        senderLogged = true
        log(string.format("[chat] sender for replies: %s (expected type %s)",
            chosen and shortClass(chosen) or "none found",
            tostring(info and info.objClassName or sampledClass or "unknown")))
    end
    return chosen
end

local recvSampleLogs = 0
local function captureChatTemplate(rawParams)
    if not recvParams then return end
    local sample, textKey, desc = {}, nil, {}
    local now = os.time()
    for i, p in ipairs(recvParams) do
        local v = unwrap(rawParams[i])
        if p.fields then
            sample[i] = {}
            for _, f in ipairs(p.fields) do
                local okf, fv = pcall(function() return v[f.name] end)
                local val = okf and readValue(f.ptype, fv) or nil
                sample[i][f.name] = { ptype = f.ptype, value = val }
                desc[#desc + 1] = string.format("%s(%s)=%s", f.name, f.ptype, clip(val))
                if type(val) == "string" and recentPlayerChat[val] and now - recentPlayerChat[val] <= 15 then
                    textKey = textKey or { i = i, field = f.name }
                end
            end
        else
            local val = readValue(p.ptype, v)
            sample[i] = { ptype = p.ptype, value = val }
            desc[#desc + 1] = string.format("%s(%s)=%s", p.name, p.ptype, clip(val))
            if type(val) == "string" and recentPlayerChat[val] and now - recentPlayerChat[val] <= 15 then
                textKey = textKey or { i = i }
            end
        end
    end
    if recvSampleLogs < 3 then
        recvSampleLogs = recvSampleLogs + 1
        log("[chat sample] " .. table.concat(desc, ", ") ..
            (textKey and (" -> text is in " .. (textKey.field or ("param " .. textKey.i))) or ""))
    end
    if textKey and not chatTemplate then
        chatTemplate, templateTextKey = sample, textKey
        log("[chat] learned the chat message format; replies will now show in chat.")
    end
end

-- The host's own name and user ID, used as the sender of replies.
local function hostIdentity()
    local all
    pcall(function() all = FindAllOf("PlayerController") end)
    for _, pc in ipairs(all or {}) do
        if isHost(pc) then
            local id, name = playerIdentity(pc, pawnOf(pc))
            if id:sub(1, 5) == "name:" then id = nil end
            return id, name
        end
    end
    return nil, nil
end

local function isIdField(name)
    local low = string.lower(name)
    return low:find("id$") ~= nil or low:find("steam", 1, true) ~= nil or low:find("uid", 1, true) ~= nil
        or low:find("netid", 1, true) ~= nil
end

local function templateValue(entry, isText, fieldName, msg)
    if isText then return makeValue(entry.ptype, msg) end
    if isStringType(entry.ptype) and CONFIG.REPLY_AS_HOST then
        if isIdField(fieldName) then
            local hid = hostIdentity()
            if hid then return makeValue(entry.ptype, hid) end
        elseif isSenderField(fieldName) then
            local _, hname = hostIdentity()
            if hname then return makeValue(entry.ptype, hname) end
        end
    elseif isStringType(entry.ptype) and isSenderField(fieldName) and not isIdField(fieldName) then
        return makeValue(entry.ptype, CONFIG.CHAT_SENDER_NAME)
    end
    if entry.value == nil then return nil end
    if isStringType(entry.ptype) then return makeValue(entry.ptype, entry.value) end
    return entry.value
end

local function buildChatArgs(msg)
    if not recvParams or #recvParams == 0 then return nil end
    local args = {}
    for i, p in ipairs(recvParams) do
        if chatTemplate then
            local tk = templateTextKey
            if p.fields then
                local t = {}
                for _, f in ipairs(p.fields) do
                    local entry = chatTemplate[i] and chatTemplate[i][f.name]
                    if entry then
                        local isText = tk.i == i and tk.field == f.name
                        local v = templateValue(entry, isText, f.name, msg)
                        if v ~= nil then t[f.name] = v end
                    end
                end
                args[i] = t
            else
                local entry = chatTemplate[i]
                if entry then args[i] = templateValue(entry, tk.i == i and not tk.field, p.name, msg) end
            end
        elseif p.fields then
            local t = {}
            for _, f in ipairs(p.fields) do
                local v = valueFor(f.ptype, f.name, msg)
                if v ~= nil then t[f.name] = v end
            end
            args[i] = t
        else
            args[i] = valueFor(p.ptype, p.name, msg)
        end
        -- Object fields (the sender) can't be copied from the sample; fill
        -- them with the host's own player object.
        if p.ptype == "ObjectProperty" then
            local sc = chatTemplate and chatTemplate[i] and chatTemplate[i].value
            sc = type(sc) == "string" and sc:match("^<(.*)>$") or nil
            args[i] = hostSenderObject(p, sc)
        elseif p.fields then
            for _, f in ipairs(p.fields) do
                if f.ptype == "ObjectProperty" then
                    local e = chatTemplate and chatTemplate[i] and chatTemplate[i][f.name]
                    local sc = e and type(e.value) == "string" and e.value:match("^<(.*)>$") or nil
                    args[i][f.name] = hostSenderObject(f, sc)
                end
            end
        end
    end
    return args
end

local sendingOwn = false
local function sendNow(pc, msg)
    if not chatRepliesWork or not valid(pc) then return end
    local args = buildChatArgs(msg)
    if not args then
        chatRepliesWork = false
        log("Chat replies are off: could not read the chat message format " .. paramsToString(recvParams) ..
            ". Replies will only appear in this log.")
        return
    end
    sendingOwn = true
    trace("chat reply: send")
    local ok, err = pcall(function()
        pc:ClientReceiveChatMessage(table.unpack(args, 1, #recvParams))
    end)
    sendingOwn = false
    trace("chat reply: sent")
    if not ok then
        chatRepliesWork = false
        log("Chat replies are off (the game refused the message: " .. clip(err) ..
            "). Replies will only appear in this log. Chat format: " .. paramsToString(recvParams))
    end
end

-- Replies wait a moment so they appear after the player's own chat line,
-- and so the very first reply can use the format learned from that line.
local pendingReplies = {}
local function flushReplies(force)
    if #pendingReplies == 0 then return end
    local now = os.clock()
    local keep = {}
    for _, r in ipairs(pendingReplies) do
        if force or chatTemplate or (now - r.at) >= 1.0 then
            sendNow(r.pc, r.msg)
        else
            keep[#keep + 1] = r
        end
    end
    pendingReplies = keep
end

local function tell(pc, msg)
    log("-> " .. msg)
    if not chatRepliesWork or not valid(pc) then return end
    pendingReplies[#pendingReplies + 1] = { pc = pc, msg = (CONFIG.CHAT_PREFIX or "") .. msg, at = os.clock() }
end

-- Reads the text of a chat message out of ServerSendChatMessage's params.
local chatProbeLogged = false
local function chatTextFromParams(rawParams)
    local found = nil
    local seen = {}
    for i, rp in ipairs(rawParams) do
        local v = unwrap(rp)
        local info = sendParams and sendParams[i]
        local s = toText(v)
        if s then
            seen[#seen + 1] = string.format("p%d=%q", i, s)
            if not found and s:find("/") then found = s end
        end
        local fieldNames = {}
        if info and info.fields then
            for _, f in ipairs(info.fields) do fieldNames[#fieldNames + 1] = f.name end
        end
        for _, n in ipairs({ "Message", "Text", "Body", "Content", "ChatMessage", "MessageText", "Msg" }) do
            fieldNames[#fieldNames + 1] = n
        end
        for _, n in ipairs(fieldNames) do
            local okf, fv = pcall(function() return v[n] end)
            if okf and fv ~= nil then
                local fs = toText(unwrap(fv))
                if fs then
                    seen[#seen + 1] = string.format("p%d.%s=%q", i, n, fs)
                    if not found and fs:find("/") then found = fs end
                end
            end
        end
    end
    if not chatProbeLogged then
        chatProbeLogged = true
        log("[chat check] first chat message seen. Readable values: " ..
            (#seen > 0 and table.concat(seen, ", ") or "none") ..
            " | format " .. paramsToString(sendParams))
    end
    return found
end

---------------------------------------------------------------------
-- WHAT IS THE PLAYER HOLDING?
-- The item in a player's hand has an ActionableComponent (the probe showed
-- one for the stick and a different one for the spear). This finds the
-- ones that belong to the player and reads the item they belong to.
---------------------------------------------------------------------
local itemLib
local function getItemLib()
    if itemLib and valid(itemLib) then return itemLib end
    itemLib = StaticFindObject("/Script/Icarus.Default__InventoryItemLibrary")
    if not valid(itemLib) then itemLib = nil end
    return itemLib
end

local function itemIdText(lib, item)
    local ok, id = pcall(function() return lib:GetItemID(item) end)
    if not ok then return nil end
    id = unwrap(id)
    local s = toText(id)
    if s then return s end
    for _, f in ipairs({ "RowName", "Value", "Name", "ID" }) do
        local okf, fv = pcall(function() return id[f] end)
        if okf and fv ~= nil then
            s = toText(unwrap(fv))
            if s then return s end
        end
    end
    return nil
end

local function belongsTo(obj, pawnName)
    local cur = obj
    for _ = 1, 4 do
        local owner
        pcall(function() owner = cur:GetOwner() end)
        if not valid(owner) then pcall(function() owner = cur:GetOuter() end) end
        if not valid(owner) then return false end
        local okn, n = pcall(function() return owner:GetFullName() end)
        if okn and n == pawnName then return true end
        cur = owner
    end
    return false
end

local structPropsCache = {}
local function structPropNames(obj)
    local cls
    pcall(function() cls = obj:GetClass() end)
    if not valid(cls) then return {} end
    local key = "?"
    pcall(function() key = cls:GetFullName() end)
    if structPropsCache[key] then return structPropsCache[key] end
    local names = {}
    local c, depth = cls, 0
    while valid(c) and depth < 6 do
        pcall(function()
            c:ForEachProperty(function(p)
                local pt = "?"
                pcall(function() pt = p:GetClass():GetFName():ToString() end)
                if pt == "StructProperty" then
                    pcall(function() names[#names + 1] = p:GetFName():ToString() end)
                end
            end)
        end)
        local okS, sup = pcall(function() return c:GetSuperStruct() end)
        if not okS then break end
        c = sup
        depth = depth + 1
    end
    structPropsCache[key] = names
    return names
end

-- Item IDs found in any struct property of obj (e.g. an ItemData field).
local function structItemIds(obj, lib, texts)
    if not lib then return end
    for _, pname in ipairs(structPropNames(obj)) do
        local okv, v = pcall(function() return obj[pname] end)
        if okv and v ~= nil then
            local id = itemIdText(lib, v)
            if id and id ~= "" and id ~= "None" then
                texts[#texts + 1] = pname .. "=" .. id
            end
        end
    end
end

-- Names of the 3D models an item actor shows, e.g. "SM_Stick_01".
local meshClasses = {}
local function meshNames(actor, texts)
    local comps = {}
    pcall(function() comps[#comps + 1] = actor.RootComponent end)
    for _, path in ipairs({ "/Script/Engine.StaticMeshComponent", "/Script/Engine.SkeletalMeshComponent" }) do
        local cls = meshClasses[path]
        if cls == nil then
            cls = StaticFindObject(path)
            if not valid(cls) then cls = false end
            meshClasses[path] = cls
        end
        if cls then
            pcall(function() comps[#comps + 1] = actor:GetComponentByClass(cls) end)
        end
    end
    local seen = {}
    for _, comp in ipairs(comps) do
        if valid(comp) then
            for _, field in ipairs({ "StaticMesh", "SkeletalMesh", "SkinnedAsset" }) do
                local okm, mesh = pcall(function() return comp[field] end)
                if okm and valid(mesh) then
                    local okn, n = pcall(function() return mesh:GetFName():ToString() end)
                    if okn and n and not seen[n] then
                        seen[n] = true
                        texts[#texts + 1] = "mesh=" .. n
                    end
                end
            end
        end
    end
end

-- Returns: true/false/nil (nil = couldn't tell), plus a description for the log.
local heldChecksLogged = 0
local function isHoldingWandInner(pawn)
    local pawnName = "?"
    pcall(function() pawnName = pawn:GetFullName() end)
    local lib = getItemLib()
    local cands = {}
    local comps = nil
    pcall(function() comps = FindAllOf("ActionableComponent") end)

    for _, comp in ipairs(comps or {}) do
        if valid(comp) and belongsTo(comp, pawnName) then
            local owner
            pcall(function() owner = comp:GetOwner() end)
            local hidden = false
            if valid(owner) and not sameObject(owner, pawn) then
                pcall(function() hidden = owner.bHidden == true end)
            end
            local texts = {}
            structItemIds(comp, lib, texts)
            if valid(owner) and not sameObject(owner, pawn) then
                table.insert(texts, 1, shortClass(owner))
                structItemIds(owner, lib, texts)
                meshNames(owner, texts)
            end
            cands[#cands + 1] = { texts = texts, hidden = hidden, owner = owner }
        end
    end

    local desc = {}
    local result = nil
    for _, c in ipairs(cands) do
        desc[#desc + 1] = (c.hidden and "[hidden] " or "") .. (#c.texts > 0 and table.concat(c.texts, ", ") or "(no item info)")
        if #c.texts > 0 and not c.hidden then
            if result == nil then result = false end
            for _, t in ipairs(c.texts) do
                if lowerHasAny(t, CONFIG.WAND_ITEM_MATCH) then result = true end
            end
        end
    end
    local summary = #desc > 0 and table.concat(desc, " | ") or "no held-item components found"

    if heldChecksLogged < 8 or CONFIG.VERBOSE then
        heldChecksLogged = heldChecksLogged + 1
        log(string.format("[held item check] result=%s : %s", tostring(result), summary))
        if result ~= true and heldChecksLogged <= 3 then
            for _, c in ipairs(cands) do
                if valid(c.owner) and not sameObject(c.owner, pawn) then
                    local names = {}
                    pcall(function()
                        local cl, depth = c.owner:GetClass(), 0
                        while valid(cl) and depth < 4 do
                            cl:ForEachProperty(function(p)
                                local n, t = "?", "?"
                                pcall(function() n = p:GetFName():ToString() end)
                                pcall(function() t = p:GetClass():GetFName():ToString() end)
                                names[#names + 1] = n .. ":" .. t
                            end)
                            cl = cl:GetSuperStruct()
                            depth = depth + 1
                        end
                    end)
                    log(string.format("[held item props] %s : %s", shortClass(c.owner),
                        #names > 0 and table.concat(names, ", ") or "(none readable)"))
                end
            end
        end
    end
    return result, summary
end

local function isHoldingWand(pawn)
    trace("stick check: start")
    local r, s = isHoldingWandInner(pawn)
    trace("stick check: " .. tostring(r))
    return r, s
end

local function wandCheck(pc, pawn)
    local holding = isHoldingWand(pawn)
    if holding == true then return true end
    if holding == nil and CONFIG.ALLOW_IF_HELD_ITEM_UNKNOWN then return true end
    tell(pc, "You must have a stick (or sticks) in your hand for the wand to work.")
    if holding == nil then
        warnOnce("Could not tell what the player is holding (see the [held item check] lines). " ..
            "Set ALLOW_IF_HELD_ITEM_UNKNOWN = true in the config to skip the stick check for now.")
    end
    return false
end

---------------------------------------------------------------------
-- CONTAINERS & INVENTORIES
---------------------------------------------------------------------
local function findInventory(actor)
    local aname
    local ok = pcall(function() aname = actor:GetFullName() end)
    if not ok then return nil end
    local found
    local all = FindAllOf("Inventory")
    if all then
        for _, comp in ipairs(all) do
            pcall(function()
                if comp:IsValid() then
                    local outer = comp:GetOuter()
                    if outer and outer:IsValid() and outer:GetFullName() == aname then
                        found = comp
                    end
                end
            end)
        end
    end
    return found
end

local function classAllowed(actor, list)
    if not list or #list == 0 then return true end
    return lowerHasAny(shortClass(actor), list)
end

-- The nearest actor (not a player) that owns an Inventory.
-- Only placed deployables (cupboards, crates, drills, machines...) are
-- considered, and only THEY are asked for their position. Asking an
-- arbitrary object that owns an inventory (some are templates or being
-- removed from the world) can crash the game outright.
local function nearestInventoryOwner(pawn)
    local okP, px, py, pz = pcall(locationOf, pawn)
    if not okP then return nil end

    -- Names of everything that owns an inventory (names only: no calls
    -- into the game on these objects).
    local owners = {}
    local invs
    pcall(function() invs = FindAllOf("Inventory") end)
    for _, inv in ipairs(invs or {}) do
        pcall(function()
            local outer = inv:GetOuter()
            if outer then owners[outer:GetFullName()] = true end
        end)
    end

    local deps
    pcall(function() deps = FindAllOf("Deployable") end)
    if not deps then
        warnOnce("Could not list placed deployables, so /wand from, /wand to and /wand clear can't find containers.")
        return nil
    end

    local best, bestD = nil, CONFIG.PICK_RADIUS
    for _, a in ipairs(deps) do
        local okN, n = pcall(function() return a:GetFullName() end)
        if okN and n and owners[n] and not n:find("Default__", 1, true) and valid(a) then
            local okL, x, y, z = pcall(locationOf, a)
            if okL and x then
                local dx, dy, dz = x - px, y - py, z - pz
                local d = math.sqrt(dx * dx + dy * dy + dz * dz)
                if d < bestD then best, bestD = a, d end
            end
        end
    end
    return best
end

---------------------------------------------------------------------
-- ITEM TRANSFER
---------------------------------------------------------------------
local function hasAuthority(actor)
    local ok, role = pcall(function() return actor.Role end)
    if not ok or role == nil then return true end
    local roleNum = tonumber(unwrap(role))
    if roleNum == nil then return true end
    return roleNum == 3
end

local seenExcluded = {}
local function isExcludedItem(idStr)
    local list = CONFIG.EXCLUDE_ITEM_MATCH
    if not idStr or not list or #list == 0 then return false end
    if lowerHasAny(tostring(idStr), list) then
        local low = string.lower(tostring(idStr))
        if not seenExcluded[low] then
            seenExcluded[low] = true
            dbg("Skipping item '" .. clip(idStr) .. "' (excluded).")
        end
        return true
    end
    return false
end

local slotArrayName
local function detectSlotArrayName()
    if slotArrayName then return slotArrayName end
    pcall(function()
        local st = StaticFindObject("/Script/Icarus.InventorySlotsFastArray")
        if not (st and st:IsValid()) then return end
        st:ForEachProperty(function(p)
            local full = p:GetFullName()
            if not slotArrayName and string.sub(full, 1, 13) == "ArrayProperty" then
                slotArrayName = p:GetFName():ToString()
            end
        end)
    end)
    return slotArrayName
end

local function slotCount(inv)
    local names = {}
    local detected = detectSlotArrayName()
    if detected then names[#names + 1] = detected end
    names[#names + 1] = "Slots"
    names[#names + 1] = "Items"
    for _, name in ipairs(names) do
        do
            local ok, n = pcall(function() return #inv.Slots[name] end)
            if ok and type(n) == "number" then return n end
            ok, n = pcall(function() return inv.Slots[name]:GetArrayNum() end)
            if ok and type(n) == "number" then return n end
        end
    end
    return nil
end

local function step(link, label, fn)
    local ok, a = pcall(fn)
    if not ok then
        link.halted = true
        log(string.format("STEP FAILED at '%s' (error: %s). This link is halted; " ..
            "use /wand remove on it and link it again to retry.", label, clip(a)))
        return false
    end
    return true, a
end

local function slotItemRef(inv, loc)
    local ok, item = pcall(function() return inv.Slots.Slots[loc + 1].ItemData end)
    if ok and item ~= nil then return item end
    return nil
end

local function moveOneStack(link)
    local src, dst = link.srcInv, link.dstInv
    local n = slotCount(src)
    if not n then
        warnOnce("Cannot read the slot count of a source inventory.")
        return 0
    end
    local lib = getItemLib()
    if not lib then
        warnOnce("Could not find /Script/Icarus.Default__InventoryItemLibrary.")
        return 0
    end

    for loc = 0, n - 1 do
        if unwrap(src:HasValidItemInSlot(loc)) == true then
            trace(link.label .. " slot " .. loc .. ": read item")
            local item = slotItemRef(src, loc)
            if item == nil then
                dbg("Could not read ItemData from source slot " .. loc .. ".")
            elseif isExcludedItem(itemIdText(lib, item)) then
                -- leave excluded items (e.g. fuel) in place
            else
                trace(link.label .. " slot " .. loc .. ": GetItemStackCount")
                local okc, amount = pcall(function() return lib:GetItemStackCount(item) end)
                amount = unwrap(amount)
                if not okc then
                    link.halted = true
                    log("The game rejected the item data read from the slot, so items cannot be moved with this UE4SS build. This link is halted.")
                    return 0
                end
                if type(amount) == "number" and amount >= 1 then
                    trace(link.label .. " slot " .. loc .. ": FindStackableLocation (x" .. tostring(amount) .. ")")
                    local ok, dstLoc = step(link, "dst:FindStackableLocation(item)", function()
                        return dst:FindStackableLocation(item)
                    end)
                    if not ok then return 0 end
                    dstLoc = unwrap(dstLoc)
                    if type(dstLoc) ~= "number" or dstLoc < 0 then
                        trace(link.label .. " slot " .. loc .. ": FindEmptyLocation")
                        ok, dstLoc = step(link, "dst:FindEmptyLocation(item)", function()
                            return dst:FindEmptyLocation(item)
                        end)
                        if not ok then return 0 end
                        dstLoc = unwrap(dstLoc)
                    end
                    if type(dstLoc) == "number" and dstLoc >= 0 then
                        local can
                        trace(link.label .. " slot " .. loc .. ": CanPlace at " .. dstLoc)
                        ok, can = step(link, "dst:CanPlace(item, location, true, amount)", function()
                            return dst:CanPlace(item, dstLoc, true, amount)
                        end)
                        if not ok then return 0 end
                        if unwrap(can) == true then
                            local placed
                            trace(link.label .. " slot " .. loc .. ": ManuallyPlaceItem at " .. dstLoc)
                            ok, placed = step(link, "dst:ManuallyPlaceItem(item, location, true)", function()
                                return dst:ManuallyPlaceItem(item, dstLoc, true)
                            end)
                            if not ok then return 0 end
                            if unwrap(placed) == true then
                                trace(link.label .. " slot " .. loc .. ": RemoveItem")
                                ok = step(link, "src:RemoveItem(location, amount, false)", function()
                                    src:RemoveItem(loc, amount, false)
                                end)
                                if not ok then
                                    log("WARNING: the stack was copied to the destination but could not be removed from the source (duplicate).")
                                    return 0
                                end
                                if unwrap(src:HasValidItemInSlot(loc)) == true then
                                    pcall(function() dst:RemoveItem(dstLoc, amount, false) end)
                                    link.halted = true
                                    log("WARNING: the source slot was not emptied; the copy in the destination was removed again. This link is halted.")
                                    return 0
                                end
                                trace(link.label .. " slot " .. loc .. ": moved ok")
                                if CONFIG.LOG_MOVES or CONFIG.VERBOSE then
                                    log(string.format("Moved %d item(s) from source slot %d to destination slot %d.",
                                        amount, loc, dstLoc))
                                end
                                return 1
                            end
                        end
                    end
                end
            end
        end
    end
    return 0
end

local function linkKey(link)
    local function id(i)
        return string.format("%s(%.0f,%.0f,%.0f #%s)", i.class, i.x, i.y, i.z, tostring(i.uid or 0))
    end
    return id(link.srcId) .. " -> " .. id(link.dstId)
end

local function transferItems(link, count)
    if link.halted then return 0 end
    link.label = link.label or linkKey(link)
    if not valid(link.srcInv) then
        trace(link.label .. ": find source inventory")
        link.srcInv = findInventory(link.src)
    end
    if not valid(link.dstInv) then
        trace(link.label .. ": find destination inventory")
        link.dstInv = findInventory(link.dst)
    end
    if not (link.srcInv and link.dstInv) then
        warnOnce("Could not find the Inventory of one of the linked containers.")
        return 0
    end
    local moved = 0
    for _ = 1, count do
        local m = moveOneStack(link)
        if m == 0 or link.halted then break end
        moved = moved + m
    end
    return moved
end

---------------------------------------------------------------------
-- SAVED LINKS  (links.txt in this mod's folder)
-- Line format: ownerId;ownerName;source;destination
-- where source/destination are class,x,y,z,uid
---------------------------------------------------------------------
local function modDir()
    local ok, src = pcall(function() return debug.getinfo(1, "S").source end)
    if ok and type(src) == "string" then
        src = src:gsub("^@", "")
        local dir = src:match("^(.*)[/\\]Scripts[/\\][^/\\]+$")
        if dir then return dir end
    end
    return nil
end

local SAVE_PATH
do
    local dir = modDir()
    if dir then SAVE_PATH = dir .. "\\links.txt" end
end

local function identityOf(actor)
    local x, y, z = locationOf(actor)
    local uid = 0
    pcall(function() uid = tonumber(actor.IcarusUID) or 0 end)
    return { class = shortClass(actor), x = x, y = y, z = z, uid = uid }
end

local function idToString(id)
    return string.format("%s,%.1f,%.1f,%.1f,%s", id.class, id.x, id.y, id.z, tostring(id.uid or 0))
end

local function parseId(str)
    local cls, x, y, z, uid = str:match("^([^,]+),([^,]+),([^,]+),([^,]+),([^,]*)$")
    if not cls then return nil end
    return { class = cls, x = tonumber(x), y = tonumber(y), z = tonumber(z), uid = tonumber(uid) or 0 }
end

local function saveLinks()
    if not SAVE_PATH then return end
    local f, err = io.open(SAVE_PATH, "w")
    if not f then
        log("Could not save links to " .. tostring(SAVE_PATH) .. ": " .. tostring(err))
        return
    end
    f:write("# WandLink saved links: ownerId;ownerName;source;destination  (class,x,y,z,uid)\n")
    for _, link in ipairs(links) do
        f:write(link.ownerId .. ";" .. link.ownerName .. ";" ..
            idToString(link.srcId) .. ";" .. idToString(link.dstId) .. "\n")
    end
    f:close()
end

local function loadLinks()
    if not SAVE_PATH then
        log("Saved links are off: could not work out the mod folder.")
        return
    end
    local f = io.open(SAVE_PATH, "r")
    if not f then return end
    local n = 0
    for line in f:lines() do
        line = line:gsub("\r", "")
        if line ~= "" and line:sub(1, 1) ~= "#" then
            local oid, oname, a, b = line:match("^([^;]*);([^;]*);([^;]+);([^;]+)$")
            local sid, did = a and parseId(a), b and parseId(b)
            if sid and did then
                table.insert(links, { ownerId = oid, ownerName = oname, srcId = sid, dstId = did, wasLive = false })
                n = n + 1
            end
        end
    end
    f:close()
    if n > 0 then log(string.format("Loaded %d saved link(s).", n)) end
end

local function idMatches(id, actor)
    local okI, other = pcall(identityOf, actor)
    if not okI or other.class ~= id.class then return false end
    local dx, dy, dz = other.x - id.x, other.y - id.y, other.z - id.z
    return math.sqrt(dx * dx + dy * dy + dz * dz) <= CONFIG.MATCH_TOLERANCE
end

local function reconnectLinks()
    local wanted, any = {}, false
    for _, link in ipairs(links) do
        if not valid(link.src) then
            wanted[link.srcId.class] = wanted[link.srcId.class] or {}
            table.insert(wanted[link.srcId.class], { link = link, side = "src" })
            any = true
        end
        if not valid(link.dst) then
            wanted[link.dstId.class] = wanted[link.dstId.class] or {}
            table.insert(wanted[link.dstId.class], { link = link, side = "dst" })
            any = true
        end
    end
    if not any then return end
    trace("reconnect scan")
    for cls, wants in pairs(wanted) do
        local ok, actors = pcall(function() return FindAllOf(cls) end)
        if ok and actors then
            -- Read each actor's ID once (a stored value, no call into the
            -- game). Templates are skipped.
            local byUid, noUid = {}, {}
            for _, a in ipairs(actors) do
                local okN, n = pcall(function() return a:GetFullName() end)
                if okN and n and not n:find("Default__", 1, true) and valid(a) then
                    local okU, uid = pcall(function() return tonumber(a.IcarusUID) end)
                    if okU and uid and uid ~= 0 then byUid[uid] = a else noUid[#noUid + 1] = a end
                end
            end
            for _, want in ipairs(wants) do
                local id = (want.side == "src") and want.link.srcId or want.link.dstId
                local best = nil
                if id.uid and id.uid ~= 0 then
                    best = byUid[id.uid]
                else
                    -- Old saves without an ID: fall back to position, only
                    -- for actors that have no ID either.
                    local bestD = CONFIG.MATCH_TOLERANCE
                    for _, a in ipairs(noUid) do
                        local okl, x, y, z = pcall(locationOf, a)
                        if okl and x then
                            local dx, dy, dz = x - id.x, y - id.y, z - id.z
                            local d = math.sqrt(dx * dx + dy * dy + dz * dz)
                            if d < bestD then best, bestD = a, d end
                        end
                    end
                end
                if best then
                    want.link[want.side] = best
                    want.link.srcInv, want.link.dstInv = nil, nil
                    want.link.halted = want.link.crashHalted or false
                    want.link.safeRuns, want.link.idleDelay, want.link.nextAt = 0, nil, nil
                    trace("reconnected " .. (want.side == "src" and "source" or "destination") .. " of " .. linkKey(want.link))
                end
            end
        end
    end
end

---------------------------------------------------------------------
-- LINK LOOP
---------------------------------------------------------------------
-- Runs on the game thread (see the TICKER at the bottom of the file).
--
-- Spread out so the game never stutters:
--   * at most ONE link is handled per game-thread tick (every 0.1 s), so
--     the work for many links is spread over many frames instead of all
--     landing in one frame;
--   * each link is handled every TICK_MS while it is moving items; when it
--     moves nothing (source empty, destination full or refusing the item)
--     it is checked less and less often, up to IDLE_MAX_SECONDS, and goes
--     back to normal as soon as something moves;
--   * the crash guard file is only written for a link's first few passes
--     after it (re)connects, not on every pass.
local GUARD_RUNS = 3
local IDLE_MAX_SECONDS = 30
local reconnectAt = 0
local rrIndex = 0
local serverCache, serverCacheAt = false, -100

local function cachedIsServer(now)
    if now - serverCacheAt >= 2 then
        serverCache, serverCacheAt = isServer(), now
    end
    return serverCache
end

local function runLink(link, now)
    local base = CONFIG.TICK_MS / 1000
    if valid(link.src) and valid(link.dst) then
        if not link.wasLive then
            link.wasLive = true
            dbg("Link active.")
        end
        local moved = 0
        local okd, d = pcall(distance, link.src, link.dst)
        if okd and d <= CONFIG.MAX_DISTANCE and not link.halted then
            local authOk, authed = pcall(hasAuthority, link.src)
            if not authOk or authed then
                local guarded = (link.safeRuns or 0) < GUARD_RUNS
                if guarded then setGuard(linkKey(link)) end
                local ok, res = pcall(transferItems, link, CONFIG.ITEMS_PER_TICK)
                if guarded then
                    clearGuard()
                    link.safeRuns = (link.safeRuns or 0) + 1
                end
                if ok then
                    moved = tonumber(res) or 0
                else
                    log("Transfer error: " .. clip(res))
                end
            end
        end
        if moved > 0 then
            link.idleDelay = nil
        else
            link.idleDelay = math.min((link.idleDelay or base) * 2, IDLE_MAX_SECONDS)
        end
        link.nextAt = now + (link.idleDelay or base)
    else
        if link.wasLive then
            link.wasLive = false
            link.srcInv, link.dstInv = nil, nil
            dbg("Link paused: a container is no longer loaded.")
        end
        link.nextAt = now + base
    end
end

local function linkTick(now)
    if not cachedIsServer(now) then return end
    local n = #links
    if n == 0 then return end

    -- Looking for unloaded containers again gets its own tick.
    if now >= reconnectAt then
        reconnectAt = now + (CONFIG.TICK_MS / 1000) * CONFIG.RECONNECT_EVERY_TICKS
        local ok, err = pcall(reconnectLinks)
        if not ok then log("Reconnect error: " .. clip(err)) end
        return
    end

    -- Handle the next link that is due (one per tick).
    for _ = 1, n do
        rrIndex = rrIndex % n + 1
        local link = links[rrIndex]
        if link and (link.nextAt or 0) <= now then
            runLink(link, now)
            return
        end
    end
end

---------------------------------------------------------------------
-- WAND ACTIONS
---------------------------------------------------------------------
local function countOwned(key)
    local n = 0
    for _, l in ipairs(links) do if l.ownerId == key then n = n + 1 end end
    return n
end

local function doLink(pc, key, name, st, container)
    trace("doLink: start (" .. (st.from and "TO" or "FROM") .. ")")
    if not st.from then
        if not classAllowed(container, CONFIG.SOURCE_CLASSES) then
            tell(pc, prettyName(container) .. " can't be used as a FROM container.")
            return
        end
        st.from = container
        tell(pc, "FROM set: " .. prettyName(container) .. ". Now open the TO container.")
        return
    end
    if not valid(st.from) then
        st.from = nil
        tell(pc, "The FROM container is no longer loaded. Open the FROM container again.")
        return
    end
    if sameObject(st.from, container) then
        tell(pc, "That's the FROM container. Open a different container as the TO side.")
        return
    end
    if not classAllowed(container, CONFIG.DEST_CLASSES) then
        tell(pc, prettyName(container) .. " can't be used as a TO container.")
        return
    end
    trace("doLink: distance")
    local d = distance(st.from, container)
    if d > CONFIG.MAX_DISTANCE or d < CONFIG.MIN_DISTANCE then
        tell(pc, string.format("Those containers are %.0f m apart; links must be between %.0f and %.0f m.",
            d / 100, CONFIG.MIN_DISTANCE / 100, CONFIG.MAX_DISTANCE / 100))
        return
    end
    trace("doLink: duplicate check")
    for _, l in ipairs(links) do
        if idMatches(l.srcId, st.from) and idMatches(l.dstId, container) then
            tell(pc, "Those two containers are already linked.")
            st.from = nil
            return
        end
    end
    trace("doLink: identities")
    local rec = {
        ownerId = key, ownerName = name,
        srcId = identityOf(st.from), dstId = identityOf(container),
        src = st.from, dst = container, wasLive = true,
    }
    table.insert(links, rec)
    trace("doLink: save")
    saveLinks()
    trace("doLink: linked " .. linkKey(rec))
    tell(pc, string.format("Linked %s -> %s (%.0f m apart). Items will start moving.",
        prettyName(st.from), prettyName(container), d / 100))
    log(string.format("%s made a link. Total links: %d", name, #links))
    st.from = nil
end

local function doRemove(pc, key, name, st, container)
    trace("doRemove: " .. shortClass(container))
    local mayRemoveAll = (not CONFIG.ONLY_OWNER_CAN_REMOVE) or isHost(pc)
    local removed, blocked = 0, 0
    for i = #links, 1, -1 do
        local l = links[i]
        if idMatches(l.srcId, container) or idMatches(l.dstId, container) then
            if mayRemoveAll or l.ownerId == key then
                table.remove(links, i)
                removed = removed + 1
            else
                blocked = blocked + 1
            end
        end
    end
    if removed > 0 then saveLinks() end
    local msg = string.format("Removed %d link(s) from %s.", removed, prettyName(container))
    if blocked > 0 then
        msg = msg .. string.format(" %d other link(s) belong to someone else and were kept.", blocked)
    end
    tell(pc, msg)
    st.mode = "link"
end

-- Called when a player opens a container.
local lastOpen = {}
local closeEventSeen = false

-- Called when a player closes a container.
local function onContainerClosed(pawn)
    closeEventSeen = true
    local key = playerIdentity(controllerOf(pawn), pawn)
    if lastOpen[key] then lastOpen[key].closed = true end
end
local function onContainerOpened(pawn, container)
    if not isServer() then return end
    local pc = controllerOf(pawn)
    local key, name = playerIdentity(pc, pawn)
    local st = players[key]
    if not st or not st.on then return end
    trace("open by " .. name .. ": " .. shortClass(container))

    -- The same open can be reported by more than one game function; only
    -- handle it once. A container counts as opened again only after the
    -- player has closed it (or, if the close event is never seen, after a
    -- couple of seconds).
    local cname = "?"
    pcall(function() cname = container:GetFullName() end)
    local now = os.time()
    local last = lastOpen[key]
    if last and last.name == cname and not last.closed then
        if closeEventSeen or (now - last.at) <= 2 then return end
    end
    lastOpen[key] = { name = cname, at = now, closed = false }

    trace("open: find inventory")
    if not findInventory(container) then
        dbg("Opened something without an inventory: " .. cname)
        return
    end
    trace("open: stick check")
    if not wandCheck(pc, pawn) then return end
    trace("open: stick ok, mode " .. st.mode)

    if st.mode == "remove" then
        doRemove(pc, key, name, st, container)
    else
        doLink(pc, key, name, st, container)
    end
end

-- /wand commands
local function onChatCommand(pc, text)
    local cmd = string.lower((text:gsub("^%s+", ""):gsub("%s+$", "")))
    if cmd ~= "/wand" and cmd:sub(1, 6) ~= "/wand " then return end
    if not isServer() then return end
    local arg = cmd:sub(7):gsub("^%s+", "")
    trace("chat command '" .. cmd .. "'")
    local pawn = pawnOf(pc)
    local key, name = playerIdentity(pc, pawn)
    local st = stateFor(key)

    if arg == "" or arg == "on" or arg == "off" then
        local turnOn
        if arg == "on" then turnOn = true elseif arg == "off" then turnOn = false else turnOn = not st.on end
        st.on, st.mode, st.from = turnOn, "link", nil
        if turnOn then
            log(name .. " turned wand mode on.")
            tell(pc, "Wand ON. Hold a stick, open the FROM container, then the TO container. Type /wand to turn it off.")
            if pawn and isHoldingWand(pawn) ~= true then
                tell(pc, "Reminder: you must have a stick (or sticks) in your hand for the wand to work.")
            end
        else
            log(name .. " turned wand mode off.")
            tell(pc, "Wand OFF.")
        end
    elseif arg == "remove" then
        st.on, st.mode, st.from = true, "remove", nil
        tell(pc, "Holding a stick, open a container to remove its links.")
    elseif arg == "cancel" then
        st.from, st.mode = nil, "link"
        tell(pc, "Cancelled. Open a new FROM container.")
    elseif arg == "list" then
        tell(pc, string.format("You own %d link(s). %d link(s) in total.", countOwned(key), #links))
    elseif arg == "from" or arg == "to" or arg == "clear" then
        -- Act on the container nearest the player instead of opening one.
        -- (Keybinds send these, for the host and for friends who join.)
        if not pawn then return end
        if CONFIG.KEYBINDS.REQUIRE_STICK and not wandCheck(pc, pawn) then return end
        trace("command: nearest container")
        local container = nearestInventoryOwner(pawn)
        if not container then
            tell(pc, string.format("No container within %.0f m. Stand closer.", CONFIG.PICK_RADIUS / 100))
            return
        end
        trace("command: nearest is " .. shortClass(container))
        if arg == "from" then
            st.from, st.mode = nil, "link"
            doLink(pc, key, name, st, container)
        elseif arg == "to" then
            if not st.from then
                tell(pc, "Set a FROM container first.")
                return
            end
            st.mode = "link"
            doLink(pc, key, name, st, container)
        else
            doRemove(pc, key, name, st, container)
        end
    else
        tell(pc, "Wand commands: /wand (on/off), /wand remove, /wand cancel, /wand list. " ..
            "Nearest container: /wand from, /wand to, /wand clear.")
    end
end

---------------------------------------------------------------------
-- OPTIONAL KEYBINDS (CONFIG.KEYBINDS.ENABLED)
-- Keys are read by the game on the computer running the mod, so they only
-- ever act for the host. See README.md.
---------------------------------------------------------------------
local function hostPlayer()
    local all
    pcall(function() all = FindAllOf("PlayerController") end)
    for _, pc in ipairs(all or {}) do
        if isHost(pc) then return pc, pawnOf(pc) end
    end
    return nil, nil
end

local KEY_COMMANDS = {
    toggle = "/wand", from = "/wand from", to = "/wand to",
    remove = "/wand clear", cancel = "/wand cancel", list = "/wand list",
}

local function keyAction(action)
    local cmd = KEY_COMMANDS[action]
    local pc = hostPlayer()  -- this computer's own player
    if not pc then log("Keybind: no player found yet.") return end

    if isServer() then
        -- Host (or single player): run the command directly.
        onChatCommand(pc, cmd)
    else
        -- Joined to someone else's world: send the command through chat,
        -- so the host's copy of WandLink runs it for this player.
        local ok, err = pcall(function() pc:ServerSendChatMessage(cmd) end)
        if ok then
            log("Keybind sent '" .. cmd .. "' to the host.")
        else
            log("Keybind could not send '" .. cmd .. "' to the host: " .. clip(err))
        end
    end
end

local function setupKeybinds()
    local kb = CONFIG.KEYBINDS
    if not (kb and kb.ENABLED) then return end
    local map = {
        { kb.TOGGLE_WAND, "toggle" }, { kb.SET_FROM, "from" }, { kb.SET_TO, "to" },
        { kb.REMOVE, "remove" }, { kb.CANCEL, "cancel" }, { kb.LIST, "list" },
    }
    local bound = {}
    for _, m in ipairs(map) do
        local keyName, action = m[1], m[2]
        if keyName and keyName ~= "" then
            local k = Key[string.upper(keyName)]
            if k == nil then
                log("Keybind '" .. tostring(keyName) .. "' for " .. action .. " isn't a key UE4SS knows; skipped.")
            else
                local ok, err = pcall(function()
                    RegisterKeyBind(k, function()
                        ExecuteInGameThread(function()
                            local okA, errA = pcall(keyAction, action)
                            if not okA then log("Keybind error: " .. clip(errA)) end
                        end)
                    end)
                end)
                if ok then
                    bound[#bound + 1] = string.upper(keyName) .. "=" .. action
                else
                    log("Could not bind " .. keyName .. ": " .. clip(err))
                end
            end
        end
    end
    if #bound > 0 then log("Keybinds on: " .. table.concat(bound, ", ")) end
end

---------------------------------------------------------------------
-- HOOKS
---------------------------------------------------------------------
-- Collects every UObject passed to a hooked function (context first).
local function objectsFrom(ctx, ...)
    local objs = {}
    local okc, c = pcall(function() return ctx:get() end)
    if okc and valid(c) then objs[#objs + 1] = c end
    for _, p in ipairs({ ... }) do
        local okp, v = pcall(function() return p:get() end)
        if okp and (type(v) == "userdata" or type(v) == "table") and valid(v) then objs[#objs + 1] = v end
    end
    return objs
end

local function hookOpen(path, allowNearestFallback)
    local ok, err = pcall(function()
        RegisterHook(path, function(ctx, ...)
            local hookParams = { ... }
            local okh, herr = pcall(function()
                local objs = objectsFrom(ctx, table.unpack(hookParams))
                local pawn, container
                for _, o in ipairs(objs) do
                    if not pawn and isPlayerCharacter(o) then
                        pawn = o
                    elseif not container and not isPlayerCharacter(o) and not isPlayerController(o) then
                        local isActor = pcall(function() return o:K2_GetActorLocation() end)
                        if isActor then container = o end
                    end
                end
                if not pawn then return end
                if not container and allowNearestFallback then
                    container = nearestInventoryOwner(pawn)
                end
                if container then onContainerOpened(pawn, container) end
            end)
            if not okh then log("Open hook error: " .. clip(herr)) end
        end)
    end)
    if ok then
        log("Watching " .. path)
    else
        log("Could not watch " .. path .. " : " .. clip(err))
    end
end

local function hookClose(path)
    local ok, err = pcall(function()
        RegisterHook(path, function(ctx, ...)
            local okh, herr = pcall(function()
                local c = ctx:get()
                if isPlayerCharacter(c) then onContainerClosed(c) end
            end)
            if not okh then log("Close hook error: " .. clip(herr)) end
        end)
    end)
    if ok then
        log("Watching " .. path)
    else
        log("Could not watch " .. path .. " : " .. clip(err))
    end
end

local function hookChatReceive()
    local ok, err = pcall(function()
        RegisterHook(CHAT_RECV_PATH, function(ctx, ...)
            if sendingOwn or chatTemplate then return end
            local hookParams = { ... }
            local okh, herr = pcall(function() captureChatTemplate(hookParams) end)
            if not okh then log("Chat sample error: " .. clip(herr)) end
        end)
    end)
    if not ok then log("Could not watch incoming chat (" .. clip(err) .. ").") end
end

local function hookChat()
    local ok, err = pcall(function()
        RegisterHook(CHAT_SEND_PATH, function(ctx, ...)
            local hookParams = { ... }
            local okh, herr = pcall(function()
                local pc = ctx:get()
                if not valid(pc) then return end
                local text = chatTextFromParams(hookParams)
                if text then
                    recentPlayerChat[text] = os.time()
                    onChatCommand(pc, text)
                end
            end)
            if not okh then log("Chat hook error: " .. clip(herr)) end
        end)
    end)
    if ok then
        log("Watching chat for /wand")
    else
        log("Could not watch chat (" .. clip(err) .. "). /wand will not work.")
    end
end

---------------------------------------------------------------------
-- START
---------------------------------------------------------------------
sendParams = describeParams(CHAT_SEND_PATH)
recvParams = describeParams(CHAT_RECV_PATH)
log("Chat send format: " .. paramsToString(sendParams))
log("Chat reply format: " .. paramsToString(recvParams))

hookChat()
hookChatReceive()
setupKeybinds()
-- Opening a deployable with E. The first passes the deployable it opened;
-- the second is a backup that announces the same open.
hookOpen("/Script/Icarus.IcarusPlayerCharacter:SetInteractingWithDeployable", false)
hookOpen("/Script/Icarus.DeployableSubsystem:BroadcastDeployableInteractedDelegate", false)
hookClose("/Script/Icarus.IcarusPlayerCharacter:StopInteractingWithDeployable")

loadLinks()
do
    local crashed = readGuard()
    if crashed and crashed ~= "" then
        local hits = 0
        for _, l in ipairs(links) do
            if linkKey(l) == crashed then
                l.halted, l.crashHalted = true, true
                hits = hits + 1
            end
        end
        log("WARNING: the game crashed last time while this link was moving items: " .. crashed ..
            ". It is switched off for this session (" .. hits .. " match). " ..
            "Remove it with /wand remove, or restart to try it again.")
        clearGuard()
    end
end
---------------------------------------------------------------------
-- TICKER
-- All of WandLink's periodic work (moving items, finding containers again,
-- sending chat replies) runs from ONE place, on the game thread.
-- Background-thread timers (LoopAsync) share the mod's Lua state with the
-- game thread, which is not safe in this UE4SS version and can crash the
-- game ("Ref was not function"). So the game's own frame tick is used when
-- UE4SS offers it, and a single slow background timer only as a fallback.
---------------------------------------------------------------------
local nextReplyFlush = 0
local tickSeen = false
local function onTick()
    local now = os.clock()
    if not tickSeen then
        tickSeen = true
        log("Timer running.")
    end
    if now >= nextReplyFlush then
        nextReplyFlush = now + 0.2
        local ok, err = pcall(flushReplies, false)
        if not ok then log("Reply error: " .. clip(err)) end
    end
    local ok, err = pcall(linkTick, now)
    if not ok then log("Link tick error: " .. clip(err)) end
end

local function startTicker()
    -- 1) The engine's frame tick (runs on the game thread every frame).
    for _, apiName in ipairs({ "RegisterEngineTickPreHook", "RegisterEngineTickPostHook" }) do
        local api = _G[apiName]
        if type(api) == "function" then
            local ok = pcall(function() api(function() onTick() end) end)
            if ok then return apiName .. " (game thread, every frame)" end
        end
    end
    -- 2) A game-thread repeating timer.
    for _, apiName in ipairs({ "LoopInGameThreadWithDelay", "LoopInGameThread" }) do
        local api = _G[apiName]
        if type(api) == "function" then
            local ok = pcall(function() api(100, function() onTick() end) end)
            if ok then return apiName .. " (game thread, every 0.1 s)" end
        end
    end
    -- 3) Fallback: ONE slow background timer that hands the work to the
    --    game thread (was two timers, one of them 5 times a second).
    LoopAsync(500, function()
        ExecuteInGameThread(function() onTick() end)
        return false
    end)
    return "LoopAsync fallback (every 0.5 s)"
end

local tickerKind = startTicker()
log("Timer: " .. tickerKind)
trace("---- WandLink started (timer: " .. tickerKind .. ") ----")
log("Loaded. Type /wand in game chat to start linking.")
