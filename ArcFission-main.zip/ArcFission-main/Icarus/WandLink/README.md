# WandLink

Link two containers in Icarus with a stick "wand", and items flow from one
into the other automatically. Everything can be done with chat commands
and by opening containers with F.
Keybinds can be set by changing line 73 in the main.lua to `true`.
Keybinds are also able to be changed by changing the binds in lines
77-82 to your choice of bind (see [Keybinds](#keybinds)).

Only the **host** needs the mod installed. Friends just type the commands
in chat.

## Install

1. Put the folder in your UE4SS `Mods` folder:

   ```
   <Icarus>/Icarus/Binaries/Win64/ue4ss/Mods/
     WandLink/
       enabled.txt
       README.md
       Scripts/
         main.lua
   ```

2. WandLink needs an **experimental UE4SS build**.

## Using the wand

| Do this | What happens |
|---|---|
| Type `/wand` in chat | Wand mode turns on for you (type it again to turn it off) |
| Hold a stick (or a stack of sticks) | Required: without one, you get a chat message saying so |
| Open the FROM container with F | "FROM set" appears in chat |
| Open the TO container with F | The link is made and saved, and items start moving |

FROM can be a cupboard, a drill or anything else with an inventory. TO
can be anything with an inventory.

### Other commands

| Command | What it does |
|---|---|
| `/wand remove` | The next container you open (holding a stick) has its links removed |
| `/wand cancel` | Forget a FROM container you picked but haven't linked yet |
| `/wand list` | How many links you own, and how many exist in total |
| `/wand help` | Shows the commands in chat |
| `/wand from` | The container nearest you (within 6 m) becomes FROM, without opening it |
| `/wand to` | The container nearest you becomes TO, and the link is made |
| `/wand clear` | Remove the links on the container nearest you |

`/wand from`, `/wand to` and `/wand clear` also need a stick in hand.

Each link remembers who made it. With `/wand remove` and `/wand clear`,
players can only remove their own links. The host can remove anyone's.

## Keybinds

Keybinds are turned on and off with `ENABLED` under `KEYBINDS` (line 73
of `Scripts/main.lua`). Use `true` or `false`, in lowercase and without
quotes. The keys themselves are on lines 77-82, and can be changed to
any key you like (for example `"F3"`), or set to `""` to leave one
unbound.

| Key | Same as | What it does |
|---|---|---|
| F4 | `/wand` | Wand mode on/off |
| F5 | `/wand from` | Nearest container becomes FROM |
| F6 | `/wand to` | Nearest container becomes TO, and the link is made |
| F7 | `/wand cancel` | Cancel a FROM you haven't linked yet |
| F8 | `/wand clear` | Clear the links on the nearest container |
| F9 | `/wand list` | List links |

F10, F11 and F12 are left alone on purpose (F10 opens the console with
the console mod, F11 toggles fullscreen, F12 takes a screenshot).

### Keybinds in multiplayer

- **The host's keys** run the command straight away.
- **A friend who joins** needs WandLink installed too, with keybinds
  turned on in their own copy. Their keys send the matching `/wand`
  command through chat to the host, so the host must have WandLink.
- **A friend's key presses show up in chat**, because they travel as
  chat messages (everyone sees lines like `/wand from`). The host's own
  keys don't post anything.
- The **host's settings** decide everything (stick needed, distance,
  who can remove links). A friend's settings only choose their keys.

## Chat replies

Replies show in chat **as sent by the host** (host's name and avatar)
and start with `[Wand]`, for example:

> **Host**: [Wand] Linked Deep Mining Drill Electric -> Metal Cupboard (99 m apart).

Icarus only shows chat messages from a real player, so the sender has to
be the host. Turn replies off with `CHAT_REPLIES = false` (line 63).

## Settings

The settings are at the top of `Scripts/main.lua` in `CONFIG`:

- `WAND_ITEM_MATCH`: which held items count as a wand (default `{ "stick" }`).
- `SOURCE_CLASSES` / `DEST_CLASSES`: limit which containers can be linked.
  Empty means anything with an inventory.
- `ONLY_OWNER_CAN_REMOVE`: set to `false` to let anyone remove any link.
- `MAX_DISTANCE`, `TICK_MS`, `ITEMS_PER_TICK`: range and speed
  (`MAX_DISTANCE` is `900000.0`, about 9 km).
- `EXCLUDE_ITEM_MATCH`: items never moved (default `{ "fuel" }`).
- `CHAT_REPLIES`: set to `false` to turn chat replies off (see
  [Chat replies](#chat-replies)).
- `CHAT_PREFIX`: text in front of every reply (default `"[Wand] "`).
- `KEYBINDS`: see [Keybinds](#keybinds).

Links are saved in `links.txt` in this folder.
